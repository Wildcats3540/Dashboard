package com.wildcatrobotics.dashboard.net;

public class NetManger extends Thread {

}
